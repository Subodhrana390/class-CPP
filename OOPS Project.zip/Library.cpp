#include <bits/stdc++.h>
#include <fstream>
#include <chrono>
#include <ctime>
using namespace std;

class Book {
public:
    string title;
    string author;
    string ISBN;
    bool isCheckedOut;

    Book(string t, string a, string isbn)
        : title(t), author(a), ISBN(isbn), isCheckedOut(false) {}

    void displayDetails() const {
        cout << "Title: " << title << ", Author: " << author
             << ", ISBN: " << ISBN << ", Status: "
             << (isCheckedOut ? "Checked Out" : "Available") << endl;
    }

    bool checkOut() {
        if (isCheckedOut) {
            return false;
        }
        isCheckedOut = true;
        return true;
    }

    bool returnBook() {
        if (!isCheckedOut) {
            return false;
        }
        isCheckedOut = false;
        return true;
    }

    string getTitle() const { return title; }
    bool isAvailable() const { return !isCheckedOut; }
};

class User {
public:
    string username;
    string password;

    User(const string &user, const string &pass)
        : username(user), password(pass) {}
};

class UserManager {
private:
    vector<User> users;

public:
    void loadUsers(const string &filename) {
        ifstream inFile(filename);
        string line;
        while (getline(inFile, line)) {
            size_t separator = line.find(',');
            string user = line.substr(0, separator);
            string pass = line.substr(separator + 1);
            users.emplace_back(user, pass);
        }
    }

    bool authenticate(string &username, string &password) const {
        for (const auto &user : users) {
            if (user.username == username && user.password == password) {
                return true;
            }
        }
        return false;
    }
};

class Library {
private:
    vector<Book> books;

public:
    void addBook(const Book &book) {
        books.push_back(book);
    }

    void displayAvailableBooks() const {
        for (const auto &book : books) {
            if (book.isAvailable()) {
                book.displayDetails();
            }
        }
    }

    Book *searchBook(const string &title) {
        for (auto &book : books) {
            if (book.getTitle() == title) {
                return &book;
            }
        }
        return nullptr;
    }

    bool checkout(const string &title) {
        for (auto &book : books) {
            if (book.getTitle() == title && book.isAvailable()) {
                return book.checkOut();
            }
        }
        return false;
    }

    bool returnBook(const string &title) {
        for (auto &book : books) {
            if (book.getTitle() == title && !book.isAvailable()) {
                return book.returnBook();
            }
        }
        return false;
    }

    void saveToFile(const string &filename) const {
        ofstream outFile(filename);
        if (outFile.is_open()) {
            for (const auto &book : books) {
                outFile << book.getTitle() << ","
                        << book.author << ","
                        << book.ISBN << ","
                        << (book.isAvailable() ? "0" : "1") << "\n";
            }
            outFile.close();
        } else {
            cerr << "Could not open file for writing." << endl;
        }
    }

    void loadFromFile(const string &filename) {
        ifstream inFile(filename);
        string line;
        while (getline(inFile, line)) {
            istringstream ss(line);
            string title, author, isbn, isCheckedOut;
            getline(ss, title, ',');
            getline(ss, author, ',');
            getline(ss, isbn, ',');
            getline(ss, isCheckedOut, ',');
            Book book(title, author, isbn);
            if (isCheckedOut == "1") {
                book.checkOut();
            }
            books.push_back(book);
        }
        inFile.close();
    }
};

int main() {
    Library library;
    UserManager userManager;

    userManager.loadUsers("users.txt");
    library.loadFromFile("books.txt");

    string username, password;
    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;

    if (!userManager.authenticate(username, password)) {
        cerr << "Authentication failed!" << endl;
        return 1;
    }

    int choice;
    do {
        cout << "\n1. Add Book\n2. View Available Books\n3. Check Out Book\n4. Return Book\n5. Save\n6. Exit\n";
        cin >> choice;

        switch (choice) {
        case 1: {
            string title, author, isbn;
            cout << "Enter title, author, and ISBN: ";
            cin.ignore();
            getline(cin, title);
            getline(cin, author);
            getline(cin, isbn);
            library.addBook(Book(title, author, isbn));
            break;
        }
        case 2:
            library.displayAvailableBooks();
            break;
        case 3: {
            string title;
            cout << "Enter title of the book to check out: ";
            cin.ignore();
            getline(cin, title);
            if (library.checkout(title)) {
                cout << title << " has been checked out." << endl;
            } else {
                cout << title << " could not be checked out." << endl;
            }
            break;
        }
        case 4: {
            string title;
            cout << "Enter title of the book to return: ";
            cin.ignore();
            getline(cin, title);
            if (library.returnBook(title)) {
                cout << title << " has been returned." << endl;
            } else {
                cout << title << " could not be returned." << endl;
            }
            break;
        }
        case 5:
            library.saveToFile("books.txt");
            cout << "Books saved to file." << endl;
            break;
        case 6:
            cout << "Exiting..." << endl;
            break;
        default:
            cout << "Invalid choice. Try again." << endl;
        }
    } while (choice != 6);

    return 0;
}
